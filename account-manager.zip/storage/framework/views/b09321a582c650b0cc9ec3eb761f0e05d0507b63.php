
<?php $__env->startSection('content'); ?>

<div class="card">
    <div class="card-header">
        <?php echo e(trans('global.create')); ?> <?php echo e(trans('cruds.transaction.title_singular')); ?>

    </div>

    <div class="card-body">
        <form method="POST" action="<?php echo e(route("admin.transactions.store")); ?>" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <div class="form-group">
                <label class="required"><?php echo e(trans('cruds.transaction.fields.transaction_type')); ?></label>
                <?php $__currentLoopData = App\Models\Transaction::TRANSACTION_TYPE_RADIO; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="form-check <?php echo e($errors->has('transaction_type') ? 'is-invalid' : ''); ?>">
                        <input class="form-check-input" type="radio" id="transaction_type_<?php echo e($key); ?>" name="transaction_type" value="<?php echo e($key); ?>" <?php echo e(old('transaction_type', 'Deposit') === (string) $key ? 'checked' : ''); ?> required>
                        <label class="form-check-label" for="transaction_type_<?php echo e($key); ?>"><?php echo e($label); ?></label>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php if($errors->has('transaction_type')): ?>
                    <div class="invalid-feedback">
                        <?php echo e($errors->first('transaction_type')); ?>

                    </div>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.transaction.fields.transaction_type_helper')); ?></span>
            </div>
            <div class="form-group">
                <label class="required" for="customer_name"><?php echo e(trans('cruds.transaction.fields.customer_name')); ?></label>
                <input class="form-control <?php echo e($errors->has('customer_name') ? 'is-invalid' : ''); ?>" type="text" name="customer_name" id="customer_name" value="<?php echo e(old('customer_name', '')); ?>" required>
                <?php if($errors->has('customer_name')): ?>
                    <div class="invalid-feedback">
                        <?php echo e($errors->first('customer_name')); ?>

                    </div>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.transaction.fields.customer_name_helper')); ?></span>
            </div>
            <div class="form-group">
                <label class="required" for="amount"><?php echo e(trans('cruds.transaction.fields.amount')); ?></label>
                <input class="form-control <?php echo e($errors->has('amount') ? 'is-invalid' : ''); ?>" type="number" name="amount" id="amount" value="<?php echo e(old('amount', '')); ?>" step="0.0001" required>
                <?php if($errors->has('amount')): ?>
                    <div class="invalid-feedback">
                        <?php echo e($errors->first('amount')); ?>

                    </div>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.transaction.fields.amount_helper')); ?></span>
            </div>
            <div class="form-group beneficiary-bank" style="display: none;">
                <label for="beneficiary_bank"><?php echo e(trans('cruds.transaction.fields.beneficiary_bank')); ?></label>
                <input class="form-control <?php echo e($errors->has('beneficiary_bank') ? 'is-invalid' : ''); ?>" type="text" name="beneficiary_bank" id="beneficiary_bank" value="<?php echo e(old('beneficiary_bank', '')); ?>">
                <?php if($errors->has('beneficiary_bank')): ?>
                    <div class="invalid-feedback">
                        <?php echo e($errors->first('beneficiary_bank')); ?>

                    </div>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.transaction.fields.beneficiary_bank_helper')); ?></span>
            </div>
            <div class="form-group">
                <label class="required" for="bank_id"><?php echo e(trans('cruds.transaction.fields.bank')); ?></label>
                <select class="form-control select2 <?php echo e($errors->has('bank') ? 'is-invalid' : ''); ?>" name="bank_id" id="bank_id" required>
                    <?php $__currentLoopData = $banks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $id => $entry): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($id); ?>" <?php echo e(old('bank_id') == $id ? 'selected' : ''); ?>><?php echo e($entry); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                <?php if($errors->has('bank')): ?>
                    <div class="invalid-feedback">
                        <?php echo e($errors->first('bank')); ?>

                    </div>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.transaction.fields.bank_helper')); ?></span>
            </div>
            <div class="form-group">
                <label class="required" for="reference"><?php echo e(trans('cruds.transaction.fields.reference')); ?></label>
                <input class="form-control <?php echo e($errors->has('reference') ? 'is-invalid' : ''); ?>" type="text" name="reference" id="reference" value="<?php echo e(old('reference', '')); ?>" required>
                <?php if($errors->has('reference')): ?>
                    <div class="invalid-feedback">
                        <?php echo e($errors->first('reference')); ?>

                    </div>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.transaction.fields.reference_helper')); ?></span>
            </div>
            <div class="form-group">
                <label for="remarks"><?php echo e(trans('cruds.transaction.fields.remarks')); ?></label>
                <textarea class="form-control <?php echo e($errors->has('remarks') ? 'is-invalid' : ''); ?>" name="remarks" id="remarks"><?php echo e(old('remarks')); ?></textarea>
                <?php if($errors->has('remarks')): ?>
                    <div class="invalid-feedback">
                        <?php echo e($errors->first('remarks')); ?>

                    </div>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.transaction.fields.remarks_helper')); ?></span>
            </div>
            <div class="form-group">
                <button class="btn btn-danger" type="submit">
                    <?php echo e(trans('global.save')); ?>

                </button>
            </div>
        </form>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<?php echo \Illuminate\View\Factory::parentPlaceholder('scripts'); ?>
<script>
        $(document).ready(function() {
        $("input[name='transaction_type']").click(function() {
            const transaction_type = $(this).val();

            if(transaction_type=="Deposit"){
                $("div.beneficiary-bank").hide();
            }else if(transaction_type=="Withdrawal"){
                $("div.beneficiary-bank").show();
            }
        });
    });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\account-manager\resources\views/admin/transactions/create.blade.php ENDPATH**/ ?>