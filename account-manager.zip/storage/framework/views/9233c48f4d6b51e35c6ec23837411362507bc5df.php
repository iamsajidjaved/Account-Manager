
<?php $__env->startSection('content'); ?>
<div class="row justify-content-center">
    <div class="col-md-9">
        <div class="card-group">
            <div class="card p-4">
                <div class="card-body">
                    <?php if(session()->has('message')): ?>
                        <p class="alert alert-info">
                            <?php echo e(session()->get('message')); ?>

                        </p>
                    <?php endif; ?>
                    <form method="POST" action="<?php echo e(route('twoFactor.check')); ?>">
                        <?php echo csrf_field(); ?>
                        <h1><?php echo e(__('global.two_factor.title')); ?></h1>
                        <p class="text-muted">
                            <?php echo e(__('global.two_factor.sub_title', ['minutes' => 15])); ?>

                        </p>

                        <div class="input-group mb-3">
                            <div class="input-group-prepend">
                                <span class="input-group-text">
                                    <i class="fa fa-lock"></i>
                                </span>
                            </div>
                            <input name="two_factor_code" type="text" class="form-control<?php echo e($errors->has('two_factor_code') ? ' is-invalid' : ''); ?>" required autofocus placeholder="<?php echo e(trans('global.two_factor.code')); ?>">
                            <?php if($errors->has('two_factor_code')): ?>
                                <div class="invalid-feedback">
                                    <?php echo e($errors->first('two_factor_code')); ?>

                                </div>
                            <?php endif; ?>
                        </div>

                        <div class="row">
                            <div class="col-6">
                                <button type="submit" class="btn btn-primary px-4">
                                    <?php echo e(trans('global.two_factor.verify')); ?>

                                </button>
                            </div>
                            <div class="col-6 text-right">
                                <a class="btn btn-secondary px-4" href="<?php echo e(route('twoFactor.resend')); ?>"><?php echo e(__('global.two_factor.resend')); ?></a>
                                <a class="btn btn-danger px-4" href="#" onclick="event.preventDefault(); document.getElementById('logoutform').submit();">
                                    <?php echo e(trans('global.logout')); ?>

                                </a>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>

<form id="logoutform" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
    <?php echo e(csrf_field()); ?>

</form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\account-manager\resources\views/auth/twoFactor.blade.php ENDPATH**/ ?>