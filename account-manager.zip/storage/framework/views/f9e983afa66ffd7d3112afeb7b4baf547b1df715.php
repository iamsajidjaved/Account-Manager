<div id="sidebar" class="c-sidebar c-sidebar-fixed c-sidebar-lg-show">

    <div class="c-sidebar-brand d-md-down-none">
        <a class="c-sidebar-brand-full h4" href="#">
            <?php echo e(trans('panel.site_title')); ?>

        </a>
    </div>

    <ul class="c-sidebar-nav">
        <li class="c-sidebar-nav-item">
            <a href="<?php echo e(route("admin.home")); ?>" class="c-sidebar-nav-link">
                <i class="c-sidebar-nav-icon fas fa-fw fa-tachometer-alt">

                </i>
                <?php echo e(trans('global.dashboard')); ?>

            </a>
        </li>
        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('user_management_access')): ?>
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('user_access')): ?>
                        <li class="c-sidebar-nav-item">
                            <a href="<?php echo e(route("admin.users.index")); ?>" class="c-sidebar-nav-link <?php echo e(request()->is("admin/users") || request()->is("admin/users/*") ? "c-active" : ""); ?>">
                                <i class="fa-fw fas fa-user c-sidebar-nav-icon">

                                </i>
                                <?php echo e(trans('cruds.user.title')); ?>

                            </a>
                        </li>
                    <?php endif; ?>
        <?php endif; ?>
        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('group_access')): ?>
            <li class="c-sidebar-nav-item">
                <a href="<?php echo e(route("admin.groups.index")); ?>" class="c-sidebar-nav-link <?php echo e(request()->is("admin/groups") || request()->is("admin/groups/*") ? "c-active" : ""); ?>">
                    <i class="fa-fw fas fa-users-cog c-sidebar-nav-icon">

                    </i>
                    <?php echo e(trans('cruds.group.title')); ?>

                </a>
            </li>
        <?php endif; ?>
        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('country_access')): ?>
            <li class="c-sidebar-nav-item">
                <a href="<?php echo e(route("admin.countries.index")); ?>" class="c-sidebar-nav-link <?php echo e(request()->is("admin/countries") || request()->is("admin/countries/*") ? "c-active" : ""); ?>">
                    <i class="fa-fw fas fa-flag c-sidebar-nav-icon">

                    </i>
                    <?php echo e(trans('cruds.country.title')); ?>

                </a>
            </li>
        <?php endif; ?>
        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('bank_access')): ?>
            <li class="c-sidebar-nav-item">
                <a href="<?php echo e(route("admin.banks.index")); ?>" class="c-sidebar-nav-link <?php echo e(request()->is("admin/banks") || request()->is("admin/banks/*") ? "c-active" : ""); ?>">
                    <i class="fa-fw fas fa-university c-sidebar-nav-icon">

                    </i>
                    <?php echo e(trans('cruds.bank.title')); ?>

                </a>
            </li>
        <?php endif; ?>
        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('transaction_access')): ?>
            <li class="c-sidebar-nav-item">
                <a href="<?php echo e(route("admin.transactions.index")); ?>" class="c-sidebar-nav-link <?php echo e(request()->is("admin/transactions") || request()->is("admin/transactions/*") ? "c-active" : ""); ?>">
                    <i class="fa-fw fas fa-clipboard-list c-sidebar-nav-icon">

                    </i>
                    <?php echo e(trans('cruds.transaction.title')); ?>

                </a>
            </li>
        <?php endif; ?>
        <?php ($unread = \App\Models\QaTopic::unreadCount()); ?>
            <li class="c-sidebar-nav-item">
                <a href="<?php echo e(route("admin.messenger.index")); ?>" class="<?php echo e(request()->is("admin/messenger") || request()->is("admin/messenger/*") ? "c-active" : ""); ?> c-sidebar-nav-link">
                    <i class="c-sidebar-nav-icon fa-fw fa fa-envelope">

                    </i>
                    <span><?php echo e(trans('global.messages')); ?></span>
                    <?php if($unread > 0): ?>
                        <strong>( <?php echo e($unread); ?> )</strong>
                    <?php endif; ?>

                </a>
            </li>
            <?php if(file_exists(app_path('Http/Controllers/Auth/ChangePasswordController.php'))): ?>
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('profile_password_edit')): ?>
                    <li class="c-sidebar-nav-item">
                        <a class="c-sidebar-nav-link <?php echo e(request()->is('profile/password') || request()->is('profile/password/*') ? 'c-active' : ''); ?>" href="<?php echo e(route('profile.password.edit')); ?>">
                            <i class="fa-fw fas fa-key c-sidebar-nav-icon">
                            </i>
                            <?php echo e(trans('global.change_password')); ?>

                        </a>
                    </li>
                <?php endif; ?>
            <?php endif; ?>
            <li class="c-sidebar-nav-item">
                <a href="#" class="c-sidebar-nav-link" onclick="event.preventDefault(); document.getElementById('logoutform').submit();">
                    <i class="c-sidebar-nav-icon fas fa-fw fa-sign-out-alt">

                    </i>
                    <?php echo e(trans('global.logout')); ?>

                </a>
            </li>
    </ul>

</div><?php /**PATH C:\laragon\www\account-manager\resources\views/partials/menu.blade.php ENDPATH**/ ?>