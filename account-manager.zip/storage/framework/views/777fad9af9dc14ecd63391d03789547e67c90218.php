
<?php $__env->startSection('content'); ?>

<div class="card">
    <div class="card-header">
        <?php echo e(trans('global.show')); ?> <?php echo e(trans('cruds.transaction.title')); ?>

    </div>

    <div class="card-body">
        <div class="form-group">
            <div class="form-group">
                <a class="btn btn-default" href="<?php echo e(route('admin.transactions.index')); ?>">
                    <?php echo e(trans('global.back_to_list')); ?>

                </a>
            </div>
            <table class="table table-bordered table-striped">
                <tbody>
                    <tr>
                        <th>
                            <?php echo e(trans('cruds.transaction.fields.id')); ?>

                        </th>
                        <td>
                            <?php echo e($transaction->id); ?>

                        </td>
                    </tr>
                    <tr>
                        <th>
                            <?php echo e(trans('cruds.transaction.fields.transaction_type')); ?>

                        </th>
                        <td>
                            <?php echo e(App\Models\Transaction::TRANSACTION_TYPE_RADIO[$transaction->transaction_type] ?? ''); ?>

                        </td>
                    </tr>
                    <tr>
                        <th>
                            <?php echo e(trans('cruds.transaction.fields.customer_name')); ?>

                        </th>
                        <td>
                            <?php echo e($transaction->customer_name); ?>

                        </td>
                    </tr>
                    <tr>
                        <th>
                            <?php echo e(trans('cruds.transaction.fields.amount')); ?>

                        </th>
                        <td>
                            <?php echo e($transaction->amount); ?>

                        </td>
                    </tr>
                    <tr>
                        <th>
                            <?php echo e(trans('cruds.transaction.fields.beneficiary_bank')); ?>

                        </th>
                        <td>
                            <?php echo e($transaction->beneficiary_bank); ?>

                        </td>
                    </tr>
                    <tr>
                        <th>
                            <?php echo e(trans('cruds.transaction.fields.bank')); ?>

                        </th>
                        <td>
                            <?php echo e($transaction->bank->bank_name ?? ''); ?>

                        </td>
                    </tr>
                    <tr>
                        <th>
                            <?php echo e(trans('cruds.transaction.fields.reference')); ?>

                        </th>
                        <td>
                            <?php echo e($transaction->reference); ?>

                        </td>
                    </tr>
                    <tr>
                        <th>
                            <?php echo e(trans('cruds.transaction.fields.status')); ?>

                        </th>
                        <td>
                            <?php echo e(App\Models\Transaction::STATUS_SELECT[$transaction->status] ?? ''); ?>

                        </td>
                    </tr>
                    <tr>
                        <th>
                            <?php echo e(trans('cruds.transaction.fields.entry_user')); ?>

                        </th>
                        <td>
                            <?php echo e($transaction->entry_user->name ?? ''); ?>

                        </td>
                    </tr>
                    <tr>
                        <th>
                            <?php echo e(trans('cruds.transaction.fields.entry_datetime')); ?>

                        </th>
                        <td>
                            <?php echo e($transaction->entry_datetime); ?>

                        </td>
                    </tr>
                    <tr>
                        <th>
                            <?php echo e(trans('cruds.transaction.fields.deposit_no')); ?>

                        </th>
                        <td>
                            <?php echo e($transaction->deposit_no); ?>

                        </td>
                    </tr>
                    <tr>
                        <th>
                            <?php echo e(trans('cruds.transaction.fields.approver')); ?>

                        </th>
                        <td>
                            <?php echo e($transaction->approver->name ?? ''); ?>

                        </td>
                    </tr>
                    <tr>
                        <th>
                            <?php echo e(trans('cruds.transaction.fields.approver_remarks')); ?>

                        </th>
                        <td>
                            <?php echo e($transaction->approver_remarks); ?>

                        </td>
                    </tr>
                    <tr>
                        <th>
                            <?php echo e(trans('cruds.transaction.fields.approve_datetime')); ?>

                        </th>
                        <td>
                            <?php echo e($transaction->approve_datetime); ?>

                        </td>
                    </tr>
                    <tr>
                        <th>
                            <?php echo e(trans('cruds.transaction.fields.remarks')); ?>

                        </th>
                        <td>
                            <?php echo e($transaction->remarks); ?>

                        </td>
                    </tr>
                </tbody>
            </table>
            <div class="form-group">
                <a class="btn btn-default" href="<?php echo e(route('admin.transactions.index')); ?>">
                    <?php echo e(trans('global.back_to_list')); ?>

                </a>
            </div>
        </div>
    </div>
</div>



<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\account-manager\resources\views/admin/transactions/show.blade.php ENDPATH**/ ?>