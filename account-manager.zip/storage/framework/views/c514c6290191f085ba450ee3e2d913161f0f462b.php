
<?php $__env->startSection('content'); ?>
<?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('transaction_create')): ?>
    <div style="margin-bottom: 10px;" class="row">
        <div class="col-lg-12">
            <a class="btn btn-success" href="<?php echo e(route('admin.transactions.create')); ?>">
                <?php echo e(trans('global.add')); ?> <?php echo e(trans('cruds.transaction.title_singular')); ?>

            </a>
        </div>
    </div>
<?php endif; ?>
<div class="card">
    <div class="card-header">
        <?php echo e(trans('cruds.transaction.title_singular')); ?> <?php echo e(trans('global.list')); ?>

    </div>

    <div class="card-body">
        <table class=" table table-bordered table-striped table-hover ajaxTable datatable datatable-Transaction">
            <thead>
                <tr>
                    <th>
                        <?php echo e(trans('cruds.transaction.fields.id')); ?>

                    </th>
                    <th>
                        <?php echo e(trans('cruds.transaction.fields.transaction_type')); ?>

                    </th>
                    <th>
                        <?php echo e(trans('cruds.transaction.fields.customer_name')); ?>

                    </th>
                    <th>
                        <?php echo e(trans('cruds.transaction.fields.amount')); ?>

                    </th>
                    <th>
                        <?php echo e(trans('cruds.transaction.fields.reference')); ?>

                    </th>
                    <th>
                        <?php echo e(trans('cruds.transaction.fields.status')); ?>

                    </th>
                    <th>
                        &nbsp;
                    </th>
                </tr>
            </thead>
        </table>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
<?php echo \Illuminate\View\Factory::parentPlaceholder('scripts'); ?>
<script>
$(function () {
  let dtOverrideGlobals = {
    processing: true,
    serverSide: true,
    retrieve: true,
    aaSorting: [],
    ajax: "<?php echo e(route('admin.transactions.index')); ?>",
    columns: [
        { data: 'id', name: 'id' },
        { data: 'transaction_type', name: 'transaction_type' },
        { data: 'customer_name', name: 'customer_name' },
        { data: 'amount', name: 'amount' },
        { data: 'reference', name: 'reference' },
        { data: 'status', name: 'status' },
        { data: 'actions', name: '<?php echo e(trans('global.actions')); ?>' }
    ],
    orderCellsTop: true,
    order: [[ 1, 'desc' ]],
    pageLength: 100,
  };
  let table = $('.datatable-Transaction').DataTable(dtOverrideGlobals);
  $('a[data-toggle="tab"]').on('shown.bs.tab click', function(e){
      $($.fn.dataTable.tables(true)).DataTable()
        .columns.adjust();
  });
  
});

</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\account-manager\resources\views/admin/transactions/index.blade.php ENDPATH**/ ?>