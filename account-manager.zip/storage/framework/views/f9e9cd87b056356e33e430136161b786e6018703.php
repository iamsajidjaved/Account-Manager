
<?php $__env->startSection('content'); ?>

<div class="card">
    <div class="card-header">
        <?php echo e(trans('global.edit')); ?> <?php echo e(trans('cruds.transaction.title_singular')); ?>

    </div>

    <div class="card-body">
        <form method="POST" action="<?php echo e(route("admin.transactions.update", [$transaction->id])); ?>" enctype="multipart/form-data">
            <?php echo method_field('PUT'); ?>
            <?php echo csrf_field(); ?>
            <div class="form-group">
                <label class="required" for="customer_name"><?php echo e(trans('cruds.transaction.fields.customer_name')); ?></label>
                <input class="form-control <?php echo e($errors->has('customer_name') ? 'is-invalid' : ''); ?>" type="text" name="customer_name" id="customer_name" value="<?php echo e(old('customer_name', $transaction->customer_name)); ?>" required>
                <?php if($errors->has('customer_name')): ?>
                    <div class="invalid-feedback">
                        <?php echo e($errors->first('customer_name')); ?>

                    </div>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.transaction.fields.customer_name_helper')); ?></span>
            </div>
            <div class="form-group">
                <label class="required" for="amount"><?php echo e(trans('cruds.transaction.fields.amount')); ?></label>
                <input class="form-control <?php echo e($errors->has('amount') ? 'is-invalid' : ''); ?>" type="number" name="amount" id="amount" value="<?php echo e(old('amount', $transaction->amount)); ?>" step="0.0001" required>
                <?php if($errors->has('amount')): ?>
                    <div class="invalid-feedback">
                        <?php echo e($errors->first('amount')); ?>

                    </div>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.transaction.fields.amount_helper')); ?></span>
            </div>
            <div class="form-group">
                <label class="required" for="bank_id"><?php echo e(trans('cruds.transaction.fields.bank')); ?></label>
                <select class="form-control select2 <?php echo e($errors->has('bank') ? 'is-invalid' : ''); ?>" name="bank_id" id="bank_id" required>
                    <?php $__currentLoopData = $banks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $id => $entry): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($id); ?>" <?php echo e((old('bank_id') ? old('bank_id') : $transaction->bank->id ?? '') == $id ? 'selected' : ''); ?>><?php echo e($entry); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                <?php if($errors->has('bank')): ?>
                    <div class="invalid-feedback">
                        <?php echo e($errors->first('bank')); ?>

                    </div>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.transaction.fields.bank_helper')); ?></span>
            </div>
            <div class="form-group">
                <label class="required" for="reference"><?php echo e(trans('cruds.transaction.fields.reference')); ?></label>
                <input class="form-control <?php echo e($errors->has('reference') ? 'is-invalid' : ''); ?>" type="text" name="reference" id="reference" value="<?php echo e(old('reference', $transaction->reference)); ?>" required>
                <?php if($errors->has('reference')): ?>
                    <div class="invalid-feedback">
                        <?php echo e($errors->first('reference')); ?>

                    </div>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.transaction.fields.reference_helper')); ?></span>
            </div>
            <div class="form-group">
                <label class="required"><?php echo e(trans('cruds.transaction.fields.status')); ?></label>
                <select class="form-control <?php echo e($errors->has('status') ? 'is-invalid' : ''); ?>" name="status" id="status">
                    <option value disabled <?php echo e(old('status', null) === null ? 'selected' : ''); ?>><?php echo e(trans('global.pleaseSelect')); ?></option>
                    <?php $__currentLoopData = App\Models\Transaction::STATUS_SELECT; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($key); ?>" <?php echo e(old('status', $transaction->status) === (string) $key ? 'selected' : ''); ?>><?php echo e($label); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                <?php if($errors->has('status')): ?>
                    <div class="invalid-feedback">
                        <?php echo e($errors->first('status')); ?>

                    </div>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.transaction.fields.status_helper')); ?></span>
            </div>
            <div class="form-group">
                <label for="deposit_no" class="required"><?php echo e(trans('cruds.transaction.fields.deposit_no')); ?></label>
                <input class="form-control <?php echo e($errors->has('deposit_no') ? 'is-invalid' : ''); ?>" type="text" name="deposit_no" id="deposit_no" value="<?php echo e(old('deposit_no', $transaction->deposit_no)); ?>">
                <?php if($errors->has('deposit_no')): ?>
                    <div class="invalid-feedback">
                        <?php echo e($errors->first('deposit_no')); ?>

                    </div>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.transaction.fields.deposit_no_helper')); ?></span>
            </div>
            <div class="form-group">
                <label for="approver_remarks"><?php echo e(trans('cruds.transaction.fields.approver_remarks')); ?></label>
                <textarea class="form-control <?php echo e($errors->has('approver_remarks') ? 'is-invalid' : ''); ?>" name="approver_remarks" id="approver_remarks"><?php echo e(old('approver_remarks', $transaction->approver_remarks)); ?></textarea>
                <?php if($errors->has('approver_remarks')): ?>
                    <div class="invalid-feedback">
                        <?php echo e($errors->first('approver_remarks')); ?>

                    </div>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.transaction.fields.approver_remarks_helper')); ?></span>
            </div>
            <div class="form-group">
                <button class="btn btn-danger" type="submit">
                    <?php echo e(trans('global.save')); ?>

                </button>
            </div>
        </form>
    </div>
</div>



<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\account-manager\resources\views/admin/transactions/edit.blade.php ENDPATH**/ ?>