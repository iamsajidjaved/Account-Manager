<?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check($viewGate)): ?>
    <a class="btn btn-xs btn-primary" href="<?php echo e(route('admin.' . $crudRoutePart . '.show', $row->id)); ?>">
        <?php echo e(trans('global.view')); ?>

    </a>
<?php endif; ?><?php /**PATH C:\laragon\www\account-manager\resources\views/partials/datatablesReadOnlyActions.blade.php ENDPATH**/ ?>