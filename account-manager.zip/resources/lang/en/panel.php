<?php

return [
    'site_title' => 'Account Manager',
];
