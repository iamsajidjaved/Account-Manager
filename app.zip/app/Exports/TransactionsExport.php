<?php

namespace App\Exports;

use Maatwebsite\Excel\Concerns\FromQuery;
use Maatwebsite\Excel\Concerns\Exportable;
use App\Models\Transaction;

class TransactionsExport implements FromQuery {
    use Exportable;

    protected $bank_id;
    protected $from;
    protected $to;

    public function __construct( $bank_id, $from, $to ) {
        $this->bank_id = $bank_id ;
        $this->from = date( 'Y-m-d', strtotime( $from ) );
        $this->to = date( 'Y-m-d', strtotime( $to ) );
    }

    public function query() {
        return Transaction::query()
        ->where( 'bank_id', $this->bank_id )
        ->whereNot( 'status', 'Void' )
        ->whereBetween( 'created_at', array( $this->from, $this->to ) );
    }
}
