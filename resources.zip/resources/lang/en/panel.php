<?php

return [
    'site_title' => 'Account Managers',
];
